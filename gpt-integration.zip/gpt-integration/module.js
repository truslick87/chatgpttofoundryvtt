// Define the module's main class
class GPTIntegrationModule extends game.Module {
  // Override the Foundry VTT module initialization function
  async initialize() {
    // Register the module settings menu
    game.settings.register('gpt-integration', 'apiToken', {
      name: 'GPT API Token',
      hint: 'Enter your GPT API token here',
      scope: 'client',
      config: true,
      type: String,
      default: '',
    });
  }

  // Override the Foundry VTT module's setup function
  async setup() {
    // Hook into the Foundry VTT chat message creation event
    Hooks.on('chatMessage', this.handleChatMessage.bind(this));
    // Hook into the Foundry VTT dice roll event
    Hooks.on('diceRollComplete', this.handleDiceRoll.bind(this));
  }

  // Handle incoming chat messages
  async handleChatMessage(chatLog, content, options) {
    // Check if the chat message is a user command to interact with GPT
    if (content.startsWith('!gpt')) {
      // Get the user's API token from the module settings
      const apiToken = game.settings.get('gpt-integration', 'apiToken');

      // Remove the command prefix and trim any extra whitespace
      const query = content.slice(4).trim();

      try {
        // Send the user's query to the GPT API for processing
        const response = await this.sendToGPT(query, apiToken);

        // Output the GPT response in the chat
        ChatMessage.create({ content: response });
      } catch (error) {
        // Handle errors and display an error message in the chat
        console.error('GPT API error:', error);
        ChatMessage.create({ content: 'An error occurred while processing the request. Please try again later.' });
      }
    }
  }

  // Handle dice rolls
  async handleDiceRoll(chatLog, roll, result, formula, options, userId) {
    // Get the current game system and rule set
    const systemId = game.system.id;
    const systemTitle = game.system.data.title;

    // Check if the dice roll is a user command
    if (roll.dice.length > 0) {
      // Get the user's API token from the module settings
      const apiToken = game.settings.get('gpt-integration', 'apiToken');

      try {
        // Construct the query string with dice roll information and game system details
        let query = `Game System: ${systemTitle} (${systemId})\n`;
        query += `Roll: ${formula} Result: ${result.total}`;
        if (result.parts.length > 0) {
          query += ` (${result.parts.map((part) => part.result).join(', ')})`;
        }

        // Send the dice roll as a query to the GPT API for processing
        const response = await this.sendToGPT(query, apiToken);

        // Output the GPT response in the chat
        ChatMessage.create({ content: response });
      } catch (error) {
        // Handle errors and display an error message in the chat
        console.error('GPT API error:', error);
        ChatMessage.create({ content: 'An error occurred while processing the request. Please try again later.' });
      }
    }
  }

  // Send user query to the GPT API for processing
  async sendToGPT(query, apiToken) {
    try {
      // Perform an API request
